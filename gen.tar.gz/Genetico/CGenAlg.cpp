#include "CGenAlg.h"
#include <QDebug>

Individual::Individual(){
    fitness = -1.0;
}

bool Individual::PushInChromosome(int element){
    chromosome.push_back(element);

    return true;
}

void Individual::PrintChromosome(){
    qDebug() << "Fitness: " << fitness << " ==========";

    for(int i = 0; i < chromosome.size(); i++)
        qDebug() << chromosome[i];

    qDebug() << "";
}

// ==================================================

RandomIndex::RandomIndex(CGraph *graph){
    int numberNodes = graph->m_nodes.size();

    for(int i = 0; i < numberNodes; i++)
        indexes.push_back(i);
}

int RandomIndex::Get(){
    if(indexes.size() == 0)
        return -1;

    int random = rand() % indexes.size();
    int index = indexes[random];

    indexes.erase(indexes.begin()+random);

    return index;
}

// ==================================================

CGenAlg::CGenAlg(CGraph *graph, int sizeInitialPopulation, int iterations){
    m_graph = graph;

    GenerateInitialPopulation(sizeInitialPopulation);

    for(int i = 0; i < iterations; i++)
        Selection();

    int i = m_indexesIndividuals[0];
    m_individuals[i].PrintChromosome();
}

void CGenAlg::PrintIndividuals(){
    for(int i = 0; i < m_individuals.size(); i++)
        m_individuals[i].PrintChromosome();
}

double CGenAlg::FitnessFunction(vector<int> *chromosome){
    double fitness = 0.0;
    int indexNodeA, indexNodeB;

    for(int i = 0; i < chromosome->size()-1; i++){
        indexNodeA = chromosome->operator [](i);
        indexNodeB = chromosome->operator [](i+1);

        fitness += m_graph->Distance(indexNodeA, indexNodeB);
    }

    return fitness;
}

bool CGenAlg::GenerateInitialPopulation(int size){
    int last;

    for(int i = 0; i < size; i++){
        m_individuals.emplace_back();
        last = m_individuals.size()-1;

        RandomIndex randIndex(m_graph);

        int newIndex = randIndex.Get();

        while(newIndex != -1){
            m_individuals[last].PushInChromosome(newIndex);
            newIndex = randIndex.Get();
        }

        int firstElement = m_individuals[last].chromosome[0];
        m_individuals[last].PushInChromosome(firstElement);

        m_individuals[last].fitness = FitnessFunction(&m_individuals[last].chromosome);

        m_indexesIndividuals.push_back(i);
    }
}

bool CGenAlg::SortFitness(){
    int temp, indexA, indexB;

    for(int j = 0; j < m_indexesIndividuals.size(); j++){
        for(int i = 0; i < m_indexesIndividuals.size()-1; i++){
            indexA = m_indexesIndividuals[i];
            indexB = m_indexesIndividuals[i+1];

            if(m_individuals[indexA].fitness > m_individuals[indexB].fitness){
                temp = m_indexesIndividuals[i];
                m_indexesIndividuals[i] = m_indexesIndividuals[i+1];
                m_indexesIndividuals[i+1] = temp;
            }
        }
    }

    return true;
}

void CGenAlg::PrintIndexesIndividuals(){
    qDebug() << "Size: " << m_indexesIndividuals.size() << " ==========";

    int indexA;

    for(int i = 0; i < m_indexesIndividuals.size(); i++){
        indexA = m_indexesIndividuals[i];
        qDebug() << m_individuals[indexA].fitness;
    }

    qDebug() << "";
}

int CGenAlg::FindInVector(vector<int> *vec, int element){
    for(int i = 0; i < vec->size(); i++){
        if(vec->operator [](i) == element)
            return i;
    }

    return -1;
}

vector<int> CGenAlg::Crossover(int indexA, int indexB){
    vector<int> *chromA = &m_individuals[indexA].chromosome;
    vector<int> *chromB = &m_individuals[indexB].chromosome;

    int module = chromA->size()-2;
    int begin = 1 + (rand() % module);
    vector<int> newChrom = *chromA;

    int pos, elementB, temp;

    for(int i = begin; i < newChrom.size()-1; i++){
        elementB = chromB->operator [](i);

        if(elementB != newChrom[0]){
            pos = FindInVector(&newChrom, elementB);
            temp = newChrom[i];

            newChrom[i] = elementB;
            newChrom[pos] = temp;
        }
    }

    return newChrom;
}

bool CGenAlg::Mutation(int indexIndiv){
    vector<int> *chrom = &m_individuals[indexIndiv].chromosome;
    int module = chrom->size()-2;
    int iterations = rand() % (chrom->size() / 4);

    int indexA, indexB, temp;
    for(int i = 0; i < iterations; i++){
        indexA = 1 + (rand() % module);
        indexB = 1 + (rand() % module);

        temp = chrom->operator [](indexA);
        m_individuals[indexIndiv].chromosome[indexA] = chrom->operator [](indexB);
        m_individuals[indexIndiv].chromosome[indexB] = temp;
    }

    return true;
}

bool CGenAlg::Selection(){
    SortFitness(); // SELECCION POR RANKING

    // CRUZAMIENTO
    int begin = m_indexesIndividuals.size() / 2;
    int currentIndex;

    for(int i = begin; i < m_indexesIndividuals.size(); i++){
        currentIndex = m_indexesIndividuals[i];
        m_individuals[currentIndex].chromosome = Crossover(i-begin, i+1-begin);
        m_individuals[currentIndex].fitness = FitnessFunction(&m_individuals[currentIndex].chromosome);
    }

    // MUTACION
    int numberMutation = m_indexesIndividuals.size() / 4;
    int j = numberMutation;

    for(int i = 0; i < numberMutation; i++){
        currentIndex = m_indexesIndividuals[j];

        if(rand() % 2 == 0)
            Mutation(currentIndex);

        j++;
    }

    return true;
}
