#ifndef CGENALG_H
#define CGENALG_H

#include <iostream>
#include <vector>

#include "CGraph.h"

using namespace std;

struct Individual{
    vector<int> chromosome;
    double fitness;

    Individual();
    bool PushInChromosome(int element);
    void PrintChromosome();
};

// ==================================================

struct RandomIndex{
    vector<int> indexes;

    RandomIndex(CGraph *graph);
    int Get();
};

// ==================================================

class CGenAlg{
    private:
        CGraph *m_graph;

        void PrintIndividuals();
        double FitnessFunction(vector<int> *chromosome);
        bool GenerateInitialPopulation(int size);
        bool SortFitness();
        void PrintIndexesIndividuals();
        int FindInVector(vector<int> *vec, int element);
        vector<int> Crossover(int indexA, int indexB);
        bool Mutation(int indexIndiv);
        bool Selection();

    public:
        vector<Individual> m_individuals;
        vector<int> m_indexesIndividuals;

        CGenAlg(CGraph *graph, int sizeInitialPopulation, int iterations);
};

#endif // CGENALG_H
