#include <time.h>

#include "DoGraphicsScene.h"
#include "DoLineaRectaObject.h"
#include "CGenAlg.h"

DoGraphicsScene::DoGraphicsScene(QObject *parent, CGraph *myGraph, int iterations) : QGraphicsScene(parent){
    srand(time(NULL));

    int zoom = 50;
    int crossSize = 3;

    // DIBUJANDO PUNTOS DEL GRAFO
    int x;
    int y;
    QPoint *newPoint;
    QPoint *newPoint1;
    QPoint *newPoint2;
    QPoint *newPoint3;
    QPoint *newPoint4;

    for(int i = 0; i < myGraph->m_number_nodes; i++){
        x = myGraph->m_nodes[i].x * zoom;
        y = myGraph->m_nodes[i].y * zoom;

        newPoint = new QPoint(x, y);
        newPoint1 = new QPoint(x+crossSize, y);
        newPoint2 = new QPoint(x-crossSize, y);
        newPoint3 = new QPoint(x, y+crossSize);
        newPoint4 = new QPoint(x, y-crossSize);

        addItem(new DoLineaRectaObject(*newPoint, *newPoint1));
        addItem(new DoLineaRectaObject(*newPoint, *newPoint2));
        addItem(new DoLineaRectaObject(*newPoint, *newPoint3));
        addItem(new DoLineaRectaObject(*newPoint, *newPoint4));

        delete newPoint;
        delete newPoint1;
        delete newPoint2;
        delete newPoint3;
        delete newPoint4;
    }

    if(iterations == 0){
        // DIBUJANDO ARISTAS DEL GRAFO
        int index_node_b;

        for(int i = 0; i < myGraph->m_distances.size(); i++){
            x = myGraph->m_nodes[i].x * zoom;
            y = myGraph->m_nodes[i].y * zoom;

            newPoint1 = new QPoint(x, y);

            for(int j = 0; j < myGraph->m_distances[i].size(); j++){
                index_node_b = myGraph->m_distances[i][j].index_node_b;

                x = myGraph->m_nodes[index_node_b].x * zoom;
                y = myGraph->m_nodes[index_node_b].y * zoom;

                newPoint2 = new QPoint(x, y);

                addItem(new DoLineaRectaObject(*newPoint1, *newPoint2));

                delete newPoint2;
            }

            delete newPoint1;
        }
    }
    else{
        // CREANDO OBJETO DEL ALGORITMO GENETICO
        CGenAlg myAlg(myGraph, 20, iterations);
        int indexSolution = myAlg.m_indexesIndividuals[0];
        vector<int> *solution = &myAlg.m_individuals[indexSolution].chromosome;

        int currentIndex;
        for(int i = 0; i < solution->size()-1; i++){
            currentIndex = solution->operator [](i);

            x = myGraph->m_nodes[currentIndex].x * zoom;
            y = myGraph->m_nodes[currentIndex].y * zoom;

            newPoint1 = new QPoint(x, y);

            currentIndex = solution->operator [](i+1);

            x = myGraph->m_nodes[currentIndex].x * zoom;
            y = myGraph->m_nodes[currentIndex].y * zoom;

            newPoint2 = new QPoint(x, y);

            addItem(new DoLineaRectaObject(*newPoint1, *newPoint2));

            delete newPoint1;
            delete newPoint2;
        }
    }
}
