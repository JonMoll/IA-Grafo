#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "DoGraphicsScene.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    myGraph = new CGraph(8, false);

    mGraphicsScene = new DoGraphicsScene(this, myGraph, 0);
    ui->graphicsView->setScene(mGraphicsScene);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    delete mGraphicsScene2;
    mGraphicsScene2 = new DoGraphicsScene(this, myGraph, 10);
    ui->graphicsView->setScene(mGraphicsScene2);
}
